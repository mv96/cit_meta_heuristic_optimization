#!/usr/bin/env python
# coding: utf-8

# Helper functions from tsp nearest neighbours

# In[37]:


from tqdm import tqdm
import random 
import math
random.seed(183262) #this is my roll number seed 


# In[38]:


# we need to make a function that domputes the distance between the two points based on the x and the y coordinates
def euc_dist(x_1,y_1,x_2,y_2):
    import math
    value=math.sqrt((x_1-x_2)**2+(y_1-y_2)**2)
    result=round(value)
    return result

def nearest_neighbour_path(nodes):
    paths=[]
    #print("="*50)
    #print("running insertion neighbours method.......\n")
    while len(nodes)!=0:# do this when lines are not zero
        val=random.randint(0,len(nodes)-1)#pick a random node to be removed takes value inc upper bound hence -1
        node=nodes.pop(val) #take out that val in the nodes and save it as the node 
        metric=(node[0],node[1],node[2])# creates metric (city_name , x_c, y_c)
    
        if(len(paths)<=1):#at first paths is an empty list insert first two elements random
        
            dist=0 #for empty list dist is zero with prev element 
            paths.append(metric)#add this metric to the empty list
    
        else:#if the list is not empty ,meaning we have some elements before
            #we will compare distance of this element with all the prev elements
        
            distances=[] #an empty list with with distances 
        
            for elements in paths: 
                dist=euc_dist(node[1],node[2],elements[1],elements[2])
                distances.append((elements[0],dist))
            
            #print("already in paths: {}\n".format(paths))
            #print("the distances of pt {} are as follows:{}\n".format(node,distances))
        
            from operator import itemgetter # run a sort based on distances stored in tuple
            distances.sort(key=itemgetter(1))
        
            #print("the min distance value is : {}\n".format(distances[0])) #this is the min distance point
        
            ###find the index of the min distance in the node and insert it
            index_check=distances[0][0] #this is the city after which it should be inserted
        
            for numbers in paths: #look for that same element in the paths 
                if(index_check==numbers[0]): #if index matches then
                    index=paths.index(numbers)#this is the index of the path node closest to the slected node
                    #print("found the index {}\n".format(index))
                    paths.insert(index+1,node) #put this element at index +1 pos and move everything right
                    break
                    
                    
    #print("paths are :{}\n".format(paths))
        
    #print(paths) #print the updated path
    first_ele=paths[0]

    #print("we also need to return back to first city , don't forget that, first element which is :{}".format(first_ele))
    if (paths[0]!=paths[-1]):#prevents over addition of same element on multiple run
        paths.append(first_ele)
    #print("="*50)
    return paths

def chromozome_to_nodes(chromozome, nodes):
    """this function converts [1,2,3,4,5,1] to [(1,x cord of 1, y cord of 1),(2,x cord of 2, y cord of 2)........
    ...........,(5,x cord of 5, y cord of 5)]"""
    final=[]
    for city in chromozome:#for every element in chromozome
        for node in nodes: #for every node in nodes
            if (node[0]==city): #if the node index= city 
                final.append(node)#add the full node value to final
    return final

def overall_cost(paths):
    """given a list of lists it iterates through it and propogates through all nodes and calc distances"""
    total=0
    for i in range(len(paths)):
        try:
            dist=euc_dist(paths[i][1],paths[i][2],paths[i+1][1],paths[i+1][2])
            #print(dist)
        except:
            break
        total+=dist
    return total

def pick_nearest_start(nodes):
    #print("="*50)
    #print("running last node fast insertion method.......\n")
    paths=[]
    cost=0
    #print("\nthis is the begining >>>>")
    #print("\nthese are the nodes lot:{}".format(nodes))
    #print("\nthese are the paths lot:{}".format(paths))
    while nodes!=0: #as soon as nodes is empty >>>stop
        if(len(paths)==0 and len(nodes)>0):#its start 
            val=random.randint(0,len(nodes)-1)
            element_removed=nodes.pop(val)
            paths.append(element_removed)
            dist=0
            cost+=dist
        elif(len(paths)!=0 and len(nodes)==0):#termination stage
            #just add the first term back again
            paths.append(paths[0])
            dist=euc_dist(paths[-1][1],paths[-1][2],paths[-2][1],paths[-2][2])
            cost+=dist
            break
            
        else: #if length is not equal to 0 then there exists some city in the path alredy
            dist=[] # compare the distance of this element present in path already with all the elements in the nodes
            last_node=paths[-1]
            
            for elements in nodes:
                d=euc_dist(last_node[1],last_node[2],elements[1],elements[2])
                dist.append((elements[0],d)) #makes a d list with (city name , distance with the removed node )
                
            from operator import itemgetter # run a sort based on distances stored in tuple
            dist.sort(key=itemgetter(1))
            
            index_check=dist[0][0] #this is the city after which it should be inserted
            dist = dist[0][1]
            
            cost+=dist
            
            found= [item for item in nodes if (item[0] == index_check)]#search the index of closest node in nodes
            nodes.remove(found[0])#only select the city name and stack it with paths
            paths.append(found[0])
            
            del dist
            
    #print("="*50)
    return paths, dist

#calculate the fitness
def fitness_tsp(population,nodes):
    """takes entire population and a list of nodes or look up table
    returns fitness"""
    dist=[]
    for chromozomes in population:
        paths=chromozome_to_nodes(chromozomes,nodes)#converts chromozomes to nodes
        val=overall_cost(paths)#calculate the cost of the node path calculated
        fitness_val=1/val #we want the least distance to be most fit hence inverse function takes care of it 
        dist.append(fitness_val) #add fitness
    return dist
    
            


# # Now we generate population for genetic algorithm ,
# 
# We have two choices either we could use one of the heuristic approach to generate samples for us or we could use the random sampling approach. 

# ## insertion neighbour heuristic- slow

# In[39]:


def heuristic_population(nodes,sample_size):
    """this funtion returns me the values from insertion neightbour heuristic as population
    for the genetic algorithm"""
    import copy
    import numpy as np
    samples=[]
    for i in tqdm(range(sample_size)):
        tnodes=copy.deepcopy(nodes)
        paths_1=nearest_neighbour_path(tnodes)#makes random path using heuristic
        #print("final path values are:{}".format(paths_1)) 
        cost_1=overall_cost(paths_1)
        #print("\ntotal cost value is:{}".format(cost_1))
        a=[]
        for vals in paths_1: #chromozoin 
            a.append(vals[0])
        samples.append(a)
    #print("samples are :{}".format(samples)) 
    return samples


# ## nearest element insert to last node based heuristic- fast

# In[40]:


def heuristic_population_fast(nodes,sample_size):
    """this funtion returns me the values from insertion neightbour heuristic as population
    for the genetic algorithm"""
    import copy
    import numpy as np
    samples=[]
    for i in tqdm(range(sample_size)):
        tnodes=copy.deepcopy(nodes)
        paths_1,cost_1=pick_nearest_start(tnodes)
        #print("final path values are:{}".format(paths_1)) 
        #print("\ntotal cost value is:{}".format(cost_1))
        a=[]
        for vals in paths_1:#for city names in a path
            a.append(vals[0])#add all the city names to a new list 
        samples.append(a)
    #print("samples are :{}".format(samples)) 
    return samples


# ## for random based population selection

# In[41]:


#implementation using the genetic algorithm 
#we need to first set the population
def random_samples(nodes,sample_size):
    import copy
    chromozome=[]
    for i in tqdm(range(sample_size)):
        tnodes=copy.deepcopy(nodes)
        temp=[]
        while len(tnodes)!=0:
            import random as random 
            val=random.randint(0,len(tnodes)-1)
            check=tnodes.pop(val)
            city_no=check[0]
            temp.append(city_no)
        temp.append(temp[0])#one samples generated
        chromozome.append(temp)#add first element back coz the tsp problem deals with returning back to the first city
    return chromozome#n such samples generated


# # we now fetch data from the data file

# In[92]:


#navigating to the problem files
import os
path = os.getcwd()
path=path+"/TSP dataset"
print(path)
os.chdir(path)
file="inst-4.tsp"
fhand=open(file)
print("name of the file is :",fhand.name)
nodes_count=fhand.readline()# read first line it shows the number of nodes in the problem  
nodes=fhand.readlines()#
import random
i=0
nodes_tuples=[]
for elements in nodes:
    elements=elements.strip()
    elements=elements.split(" ")
    elements[0]=int(elements[0])
    elements[1]=int(elements[1])
    elements[2]=int(elements[2])
    elements=tuple(elements)
    nodes_tuples.append(elements)
    
nodes=nodes_tuples
print(nodes)
os.chdir('..')#move back one lev now
path = os.getcwd()
print(path)


# the above are three ways with which we can genearate our population for applying GA (random, heuristic_1, heuristic_2)

# In[43]:


#test heuristic population code to print samples
population=heuristic_population(nodes,10) #give the nodes to make population and number of chromozomes in a population
fitness_1=fitness_tsp(population,nodes) #calculates the fitness using fitness function
print(fitness_1)

population=heuristic_population_fast(nodes,1000) #give the nodes to make population and number of chromozomes in a population
fitness_2=fitness_tsp(population,nodes) #calculates the fitness using fitness function
#print(fitness_2) #print fitness for each 

#test heuristic population code to print samples
population=random_samples(nodes,1000)
fitness_3=fitness_tsp(population,nodes)
#print(fitness_3)


# In[44]:


#a small test that compares the heuristic approach with random samples 
#a heuristic approach generally has lower number of distance generated over 10k such compared 
ele_1c=0;ele_2c=0
for ele1,ele2 in zip(fitness_2,fitness_3):
    if (ele1>ele2):
        ele_1c+=1
    else:
        ele_2c+=1
print(ele_1c,ele_2c)

#only 8k times ele1 which is heuristic fitness measure was greater then ele2 which is random sample
#rest 91k times random sample gave more distance value


# In[45]:


#by this we can conclude that using heuristic as population generation will usually will have better children
#after ga is applied


# In[46]:


def probability_from_fitness(fitness_scores,population):
    """returns a tuple of probability based value and the corresponding path"""
    total_fitness=0
    prob=[]
    for element in fitness_scores:
        total_fitness+=element
    for element,chromozome in zip(fitness_scores,population):
        proba_val=element/total_fitness
        proba_val=(proba_val,chromozome)
        prob.append(proba_val)  
    return prob


val=probability_from_fitness(fitness_1,population)
print(val)


# In[47]:


def prob_based_selection(prob_path,selection_vals):
    """this function randomly picks elements but prioritizes the higher prob routes
    returns me the prob based selected paths/chromozomes and how many we want is denoted by : selection_vals"""
    start=0
    roulette=[]#makes a roulette wheel with high values of the path
    for element in prob_path:
        start=start+element[0]
        metric=(start,element[1])
        roulette.append(metric)
    #print(roulette)

    #now pick a number between 0 and 1 and place it in roulette
    import random
    
    i=0; prob_based_paths=[]
    for i in range(selection_vals):
        num=random.uniform(0, 1)
        #print("prob_path:{}".format(num))
        #this part picks up the correct chromozome value corresponding to path selected
        start=0
        for element in roulette:
            if (num>=start and num<=element[0]):
                #print( "value is :{}".format(element[1]))
                prob_based_paths.append(element[1])
                break
            else:
                start=element[0]
                continue
    return prob_based_paths

selected=prob_based_selection(val,3)
print(selected)


# In[48]:


def top_selection(chromozome_no,prob_values):
    """picks up a fixed no of top chromozomes set based on probability value"""
    #prob by sorted list
    sorted_by_prob = sorted(prob_values, key=lambda tup: tup[0],reverse=True)#sort by 0th pos i.e probabilities
    print(sorted_by_prob)
    selected=[]
    for element in sorted_by_prob:
        if(len(selected)==chromozome_no):#just to check if total selected strands are complete or not
            break
        if(element not in selected): #if required to fill selected
            selected.append(element[1])
        else:
            continue
    return selected
    
result=top_selection(3,val)#selects the top n values
print("\nresult is:{}".format(result))


# In[49]:


def random_selection(chromozome_no,prob_values):
    """picks up any random values with no relation to probs"""
    #prob by sorted list
    import random
    sorted_by_prob = sorted(prob_values, key=lambda tup: tup[0],reverse=True)#sort by 0th pos i.e probabilities
    #print(sorted_by_prob)
    selected=[]
    for i in range(10):
        num=random.randint(0,len(sorted_by_prob)-1)
        selected.append(sorted_by_prob[num][1])
    
    return selected
    
result=random_selection(3,val)#selects the top n values
print("\nresult is:{}".format(result))


# In[50]:


#simulating crossover 

def uniform1_cross_over(strand_1,strand_2):
    import random
    import math
    import copy
    
    ## remove the last element for simplicity
    strand_1=strand_1[:-1]
    strand_2=strand_2[:-1]
    #print(strand_1,strand_2)
    
    
    #we keep the 50% genes as the same 
    fixed_pos=[] #make a list of fixed pos
    while len(fixed_pos)<math.floor(len(strand_1)/2):
        val=random.randint(0,len(strand_1)-1) 
        if(val not in fixed_pos):
            fixed_pos.append(val)
    #print("fixed_pos are :{}".format(fixed_pos))
    
    c1={}; c2={}#this is what to be preserved
    #has dict values as - index:value to be put 
    
    for element in fixed_pos:
        c1[element]=strand_1[element]
        c2[element]=strand_2[element]
        
    #print("fixed c1 dict is :{} , c2 dict is :{}".format(c1,c2))
    
    #the alphabets that need to be preserved are there in the ditionaries 
    
    #now we need to get ourselves crossing over the other values 
    ind=0
    for element in strand_2:#for all values in strand 2
        if(element in c1.values()): #if element in c1 values
            continue
        else: #if element is not there in the c1 strand
            while (ind in c1.keys()):#checking the index in c1
                ind+=1
                continue
            c1[ind]=element #add to dictionary
            ind+=1
                
    #child-2 
            
    ind=0
    for element in strand_1:#for all values in strand 2
        if(element in c2.values()): #if element in c1 values
            continue
        else: #if element is not there in the c1 strand
            while (ind in c2.keys()):#checking the index in c1
                ind+=1
                continue
            c2[ind]=element #add to dictionary
            ind+=1
            
    #print("strand c1 is: {} , c2 is : {}".format(c1,c2))
            
    #after having the fixed pos move elements of strand 2 in list 1 and vice versa
    
    #reconstruction phase
    ch1=[];ch2=[]
    
    for key1,key2 in zip(sorted(c1.keys()),sorted(c2.keys())):
        val1=c1[key1]
        ch1.append(val1)
        val2=c2[key2]
        ch2.append(val2)
        
    #print(ch1,ch2)
    #now add the first element back to the strands 
    first=ch1[0]
    ch1.append(first)
    first=ch2[0]
    ch2.append(first)
        
        
    
    return ch1,ch2

p1,p2=uniform1_cross_over([3, 2, 4, 1, 3],[2, 1, 4, 3,2])
print("strand_1: {} strand_2: {}".format(p1,p2))

###pmx crossover      
    


# In[51]:


###pmx crossover

def pmx(strand_1,strand_2):
    #simulating crossover 
    import random
    import copy
    
    ## remove the last element for simplicity
    strand_1=strand_1[:-1]
    strand_2=strand_2[:-1]
    #print(strand_1,strand_2)

    #we keep the 50% genes as the same 
    fixed_pos=[] #make a list of fixed pos
    
    while len(fixed_pos)<2:
        val1=random.randint(0,len(strand_1)-1)
        val2=random.randint(0,len(strand_1)-1)
        while val1==val2: #just to check they both have a different value
            val2=random.randint(0,len(strand_1)-1)
        if(val1>val2):#val1 has to be smaller always
            val1,val2=val2,val1 #apply swap
        fixed_pos.append(val1)
        fixed_pos.append(val2)
        
    
    #print(fixed_pos)
    
    c1={}; c2={}#this is what to be preserved
    #has dict values as - index:value to be put 
    
    for element in range(min(fixed_pos),max(fixed_pos)+1):
        c1[element]=strand_1[element]#pick the strand value and save in dictionary
        c2[element]=strand_2[element]#pick the strand value and save in dictionary
        
    #print("fixed c1 dict is :{} , c2 dict is :{}".format(c1,c2))

    for k,v in zip(c2,c1): #basically does swapping or exchnging dictionary
        temp=c1[k]
        c1[k]=c2[k]
        c2[k]=temp  
        
        
    #print("fixed c1 dict is :{} , c2 dict is :{}".format(c1,c2))
    
    #the alphabets that need to be preserved are there in the ditionaries 
    
    #now we need to get ourselves crossing over the other values 
    
    ind=0
    rj1={}
    import copy
    black1=copy.deepcopy(c1)
    
    for element in strand_1:#for all values in strand 1
        #if the element is in black range it should not be there then skip next element
        if (element in black1.values()):
            ind+=1
            continue
        if(element not in c1.values() and ind not in c1.keys()): #first check if element there in stra nd then check if the index is empty
            c1[ind]=element
            ind+=1
            continue
        else:
            ind+=1
            
    #print(c1)
                
    #child-2 
 
    ind=0
    black2=copy.deepcopy(c2)
    
    for element in strand_2:#for all values in strand 1
        #if the element is in black range it should not be there then skip next element
        if (element in black2.values()):
            #print(element,ind)
            ind+=1
            continue
        if(element not in c2.values() and ind not in c2.keys()): #first check if element there in stra nd then check if the index is empty
            c2[ind]=element
            ind+=1
            continue
        else:
            ind+=1
            
    #print(c2)     
    #print("strand c1 is: {} , c2 is : {}".format(c1,c2))
            
    #after having the fixed pos move elements of strand 2 in list 1 and vice versa

    
    #>>>>>>>>>>>>>>>>>>
    maps={}
    for item1,item2 in zip(black1.items(),black2.items()):
        maps[item1[1]]=item2[1]
        

    #reconstruction phase
    ch1=[];ch2=[]
    for i in range(len(strand_1)):
        ch1.append(None)
        ch2.append(None)
    
    for key1,key2 in zip(sorted(c1.keys()),sorted(c2.keys())):
        ch1[key1]=c1[key1]
        ch2[key2]=c2[key2]
        
    #print(ch1,strand_1)
    #print(maps)          
    
    #now add the first element back to the strands 
   
    #print("this is ch1:{},ch2:{}".format(ch1,ch2))
    
    
    
    #make rejected list
    
    rj1={}
    ind=0
    for ele1,ele2 in zip(strand_1,ch1):
        if(ele2==None):
            rj1[ind]=ele1
            ind+=1
        else:
            ind+=1
            continue  
            
    rj2={}
    ind=0
    for ele1,ele2 in zip(strand_2,ch2):
        if(ele2==None):
            rj2[ind]=ele1
            ind+=1
        else:
            ind+=1
            continue
            
    #print("this is rejected 1:{}".format(rj2))  
    
    
    for index, element in rj1.items():
        foundValue = True
        founVal = None
        
        pos1=ch1.index(element)
        while foundValue:
            value2=ch2[pos1]
            if(value2 in ch1):
                pos1 = ch1.index(value2)
                #element = ch2[pos1]
                continue
            else:
                foundVal = value2
                foundValue = False
                break
        ch1[index] = foundVal  
        
    for index, element in rj2.items():
        foundValue = True
        founVal = None
        
        pos1=ch2.index(element)
        while foundValue:
            value2=ch1[pos1]
            if(value2 in ch2):
                pos1 = ch2.index(value2)
                #element = ch2[pos1]
                continue
            else:
                foundVal = value2
                foundValue = False
                break
        ch2[index] = foundVal
    
    first=ch1[0]
    ch1.append(first)
    first=ch2[0]
    ch2.append(first)
    #print('--ch1--', ch1)
    #print('--ch2---', ch2)
    return ch1,ch2

#p1,p2=pmx([10, 2, 1, 7, 8, 4, 9, 3, 5, 6, 10] ,[9, 4, 3, 2, 7, 5, 1, 8, 10, 6, 9])
#print("strand_1: {} strand_2: {}".format(p1,p2))

p1,p2=pmx([3,4,8,2,7,1,6,5,3] ,[4,2,5,1,6,8,3,7,4])
print("strand_1: {} strand_2: {}".format(p1,p2))
           


# In[52]:


def exchange_mutation(strand_1,mutation):
    """takes strand to mutate and how many mutations to make
    returns the mutated strand"""
    import random
    cycle=0
    while cycle!=mutation: #cycle couter
        #we cant mutate the first city and last because that's the returning point
        first=random.randint(1,len(strand_1)-2)#why -2 because -1 for len value substract and another -1  not selecting last city
        second=random.randint(1,len(strand_1)-2)
        while(first==second):#to make sure the same two blocks are not selected
            second=random.randint(1,len(strand_1)-2) 
        #now we apply mutation by swapping numbers
        strand_1[first],strand_1[second]=strand_1[second],strand_1[first] #swapping operation
        cycle+=1
    
    return strand_1


result=exchange_mutation([2, 2, 4, 1, 3],2)
print("exchange mutated strand: {}".format(result))
        
       


# In[53]:


def inversion_mutation(strand_1,mutation):
    """takes strand to mutate and how many mutations to make
    returns the mutated strand"""
    import random
    cycle=0
    
    strand_1=strand_1[:-1]
    
    while cycle!=mutation: #cycle couter
        #we cant mutate the first city and last because that's the returning point
        first=random.randint(0,len(strand_1)-1)#why -2 because -1 for len value substract and another -1  not selecting last city
        second=random.randint(0,len(strand_1)-1)
        while(first==second):#to make sure the same two blocks are not selected
            second=random.randint(0,len(strand_1)-1) 
        if (first>second):
            first,second=second,first
        #print(first,second)
        #print(strand_1)
        #now we apply mutation by swapping numbers
        select=strand_1[first:second+1] #inversion operation
        #print(select)
        new=[]#make new strand
        for i in reversed(select):
            new.append(i)
        #print(new)
        strand_1[first:second+1] =new#replace selceted with new strand
        cycle+=1
        
    first=strand_1[0]
    strand_1.append(first)
    return strand_1

result=inversion_mutation([1,2,3,4,5,6,7,8,1],1)
print("inversion mutated strand: {}".format(result))  


# # running the entire GA without classes

# In[ ]:


random.seed(183262)
#navigating to the problem files
import os
from tqdm import tqdm
import os
path = os.getcwd()

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
path=path+"/TSP dataset"#<<<<<<<remove "/TSP dataset" if file is in the same level of directory
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

os.chdir(path)
file="inst-16.tsp"
#path="/Users/mv96/Desktop/cit/first semester/meta heuristics optimization/TSP dataset"
fhand=open(file)
print("name of the file is :",fhand.name)
nodes_count=fhand.readline()# read first line it shows the number of nodes in the problem  
nodes=fhand.readlines()#
import random
i=0
nodes_tuples=[]
for elements in nodes:
    elements=elements.strip()
    elements=elements.split(" ")
    elements[0]=int(elements[0])
    elements[1]=int(elements[1])
    elements[2]=int(elements[2])
    elements=tuple(elements)
    nodes_tuples.append(elements)
    
nodes=nodes_tuples
#print("nodes are :{}".format(nodes))

#move back one lev in directories
os.chdir('..')#move back one lev now

#heuristic based population generation
#print("generating neighbour insertion based approach population")
print("generating generation 0")

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
population=random_samples(nodes,100) #give the nodes to make population and number of chromozomes in a population
#for heuristic based- use heuristic_population() for(lab01, insertion neighbour)
#and use heuristic-population_fast() for (lab02 , fast heuristic)
#^^^^^^^^^^^^^^^^^^^^^^^^^^
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#for i in range runs(): <<<<< another loop can be added to run multiple runs of the same genetic algorithms each with
#500 iters

genetic_evolution=[]
current_best=None
generation_best=[]

mutation_rate=1 #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

for iterations in tqdm(range(500)): #runs these many generations test
    print("\nrunning generation:{}".format(iterations))
    fitness_1=fitness_tsp(population,nodes) #calculates the fitness using fitness function
    val=probability_from_fitness(fitness_1,population)#make probability out of the fitness values
    
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    #turn this OFF if you dont want SUS selection
    selected=prob_based_selection(val,10)#select these number of samples from population <<<denotes sus
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
    #turn this OFF if you dont want random selection
    #selected=random_selection(10,val)
    #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    
    #####generates the crossover now 
    childs=[] #this is nothing but equivalent to mating pool
    for i in range(50):#this will make 2 childs every loop
        import random
        st_1=random.randint(0,len(selected)-1)
        st_2=random.randint(0,len(selected)-1)
        #print("st_1:{} st_2:{}".format(selected[st_1],selected[st_2]))
        
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        #for pmx use pmx() instead of uniform1_cross_over
        c1,c2=pmx(selected[st_1],selected[st_2]) #<<<<<<denotes cross over
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        # for inversion use inversion instead of exchange which corresponds to reciprocal
        #mutaion rate=1 by default
        check=random.random()
        #print(check)
        if(mutation_rate>check):
            c1=inversion_mutation(c1,1)#denotes mutation
            c2=inversion_mutation(c2,1)#denotes mutation
        #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        childs.append(c1)
        childs.append(c2)
    
    #print(childs)

    #calculate current best for generation
    child_fitness=fitness_tsp(childs,nodes) #calculates the fitness for each child path , given look up table
    val=child_fitness.index(max(child_fitness)) #max value index in the list of all fitness of childs
    #print("max fitness path is {}, with fitness value: {}".format(childs[val],max(child_fitness)))
    metric=(childs[val],1/max(child_fitness))
    #add this to records of best generations
    generation_best.append(metric)
    
    #compare with overall bests
    if (iterations==0):
        current_best=metric[1]
    if (metric[1]<current_best):
        print("found a better version at:{} generation".format(iterations))
        metric=(childs[val],1/max(child_fitness),iterations)
        genetic_evolution.append(metric)
        #change my current best as metric 1
        current_best=metric[1]

    #now childs become population and the entire process repeats
    population=childs




# In[ ]:


#this piece of code selects the best solution of entire GA process and writes it down the path in the file
dist=[]
for elements in generation_best:
    dist.append(elements[1])
val=dist.index(min(dist))
overall_best=generation_best[val]

print(overall_best)

def parse_out(output_name,path,nodes_count,cost): #takes file name and nodes
    first_line="cities: "+str(nodes_count)+"cost: "+str(cost)
    file = open(output_name, "w") 
    file.write(first_line) 
    file.write("\n")
    for elements in path :
        city=str(elements)
        file.write(city)
        file.write("\n")
    file.close() 
    print("file write successful")

file_name =str(file)+"config-5"+"_"+".txt" #<<<<<set output_name
parse_out(file_name,overall_best[0],nodes_count,overall_best[1])


# In[ ]:


#this block plots the best solution among all the cities
best_of_all=[]
for elements in generation_best[val][0]:
    for node in nodes:
        if (node[0]==elements):
            best_of_all.append(node)  
            
#best path among 500 generations
x_c=[]
y_c=[]
cities=[]
for elements in best_of_all:
    x_c.append(elements[1])
    y_c.append(elements[2])
    cities.append(elements[0])
    
import matplotlib.pyplot as plt
plt.ylabel("y_cordinates")
plt.xlabel("x_cordinates")
plt.title("best path")    
plt.plot(x_c,y_c,"-b")
#plt.plot(x_c,y_c,"go",170)
plt.plot(x_c[0],y_c[0],"ro",170)


# In[ ]:


#print(genetic_evolution)
#now show the genetic evolution over iterations
dist=[]
gens=[]

for numbers in genetic_evolution:
    dist.append(numbers[1])
    gens.append(numbers[2])
    
import matplotlib.pyplot as plt
plt.xlabel("generation vice improvement of overall best")
plt.ylabel("generations where current best changes")
plt.title("transition in overall best over {} gens".format(len(gens)))        
plt.plot(gens,dist,"-b")
plt.plot(gens[0],dist[0],"ro",10)
plt.plot(gens,dist,"go",10)
print(gens)


# In[ ]:


dist=[]
gens=[]
i=0

#print(generation_best).ie. overall best

for numbers in generation_best:
    dist.append(numbers[1])
    gens.append(i)
    i+=1
    
import matplotlib.pyplot as plt
plt.xlabel("generations")
plt.ylabel("distance of the best path of a gen")
plt.title("cities:"+str(nodes_count))        
plt.plot(gens,dist,"-b")
plt.plot(gens[0],dist[0],"ro",10)  

    


# In[ ]:


val=150 #which genertion's best do you want to see 
print(generation_best[val])

best_of_all=[]
for elements in generation_best[val][0]:
    for node in nodes:
        if (node[0]==elements):
            best_of_all.append(node)  
            
#best path among 500 generations
x_c=[]
y_c=[]
cities=[]
for elements in best_of_all:
    x_c.append(elements[1])
    y_c.append(elements[2])
    cities.append(elements[0])
plt.xlabel("x_cordinates")
plt.xlabel("y_cordinates")
plt.title("generation:"+str(val))    
plt.plot(x_c,y_c,"-b")
plt.plot(x_c,y_c,"go",170)
plt.plot(x_c[0],y_c[0],"ro",170)


# In[72]:


class tsp:
    
    def __init__(self,file,generation,pop_size,selection,selection_size,cross_over,mutation,mutation_rate,_iter):
        
        self.file = file
        self.pop_size=pop_size
        self.selection_size=selection_size
        self.childs=[]
        self._iter=_iter
        self.generation_best=[]
        self.genetic_evolution=[]
        current_best=None
        nodes_count=None
        self.generation=generation
        self.selection=selection
        self.cross_over=cross_over
        self.mutation=mutation
        
        #takes care of pre processing
        
        def preprocessing():
            import os
            from tqdm import tqdm
            path = os.getcwd()
            path=path+"/TSP dataset" #this is the name of the folder where data is
            os.chdir(path) #navigate to path
            fhand=open(self.file)
            print("name of the file is :",fhand.name)
            self.nodes_count=fhand.readline()# read first line it shows the number of nodes in the problem  
            nodes=fhand.readlines()#
            import random
            i=0
            nodes_tuples=[]
            for elements in nodes:
                elements=elements.strip()
                elements=elements.split(" ")
                elements[0]=int(elements[0])
                elements[1]=int(elements[1])
                elements[2]=int(elements[2])
                elements=tuple(elements)
                nodes_tuples.append(elements)

            nodes=nodes_tuples
            
            #move back one lev in directories
            os.chdir('..')#move back one lev now
            return nodes
            
            
        
        
        self.nodes= preprocessing()
        #population generation
        """either generate random initial population or a heuristic based approach"""
    
        if(generation=="random"):
            self.population=random_samples(self.nodes,self.pop_size)
        elif(generation=="heuristic_1"):
            self.population=heuristic_population(self.nodes,self.pop_size)
        elif(generation=="heuristic_2"):
            self.population=heuristic_population_fast(self.nodes,self.pop_size)
        else:
            self.population=random_samples(self.nodes,self.pop_size) #by default run random

        for iterations in tqdm(range(_iter)): #runs these many generations test
            print("\nrunning generation:{}".format(iterations))
            
            #selection from population  
            """select chromozomes from mating pool either by randomly selecting the most fit chromozomes 
            or by using sus samples"""
            if(selection=="random"):
                fitness_1=fitness_tsp(self.population,self.nodes) #calculates the fitness using fitness function
                val=probability_from_fitness(fitness_1,self.population)#make probability out of the fitness values
                self.selected=random_selection(self.selection_size,val) #random selection
            elif(selection=="sus"):
                fitness_1=fitness_tsp(self.population,self.nodes) #calculates the fitness using fitness function
                val=probability_from_fitness(fitness_1,self.population)#make probability out of the fitness values
                self.selected=prob_based_selection(val,self.selection_size)
            else:#just use random
                fitness_1=fitness_tsp(self.population,self.nodes) #calculates the fitness using fitness function
                val=probability_from_fitness(fitness_1,self.population)#make probability out of the fitness values
                self.selected=random_selection(self.selection_size,val) #sus based selection

            #applying crossovers & mutation and making child
            for i in range(10):#this will make 2 childs every loop
                import random
                st_1=random.randint(0,len(self.selected)-1)#select one strand
                st_2=random.randint(0,len(self.selected)-1)#select second strand
                #print("st_1:{} st_2:{}".format(selected[st_1],selected[st_2]))
                if(cross_over=="uniform"):
                    c1,c2=uniform1_cross_over(self.selected[st_1],self.selected[st_2]) #apply crossovers
                elif(cross_over=="pmx"):
                    c1,c2=pmx(val,self.selection_size)   
                else:#just use uniform
                    c1,c2=uniform1_cross_over(self.selected[st_1],self.selected[st_2]) #apply crossovers
                #mutation phase
                check=random.random()
                if(mutation_rate>check):
                    if(mutation=="reciprocal"):
                        c1=exchange_mutation(c1,1)
                        c2=exchange_mutation(c2,1)
                        self.childs.append(c1)
                        self.childs.append(c2)
                    elif(mutation=="inversion"):
                        c1=inversion_mutation(c1,1)
                        c2=inversion_mutation(c2,1)
                        self.childs.append(c1)
                        self.childs.append(c2)
                    else: #by default use this
                        c1=exchange_mutation(c1,1)
                        c2=exchange_mutation(c2,1)
                        self.childs.append(c1)
                        self.childs.append(c2)
                else:
                    self.childs.append(c1)
                    self.childs.append(c2)

            child_fitness=fitness_tsp(self.childs,self.nodes) #calculates the fitness for each child path , given look up table
            val=child_fitness.index(max(child_fitness)) #max value index in the list of all fitness of childs
            #print("max fitness path is {}, with fitness value: {}".format(childs[val],max(child_fitness)))
            metric=(self.childs[val],1/max(child_fitness))
            #add this to records of best generations
            self.generation_best.append(metric)

            
            
            #compare with overall bests
            if (iterations==0): #then just add the first element as the current best
                self.current_best=metric[1]
                print("this is the current best : {}".format(self.current_best))
            if (metric[1]<self.current_best):
                print("found a better version at:{} generation".format(iterations))
                metric=(self.childs[val],1/max(child_fitness),iterations)
                self.genetic_evolution.append(metric)
                #change my current best as metric 1
                self.current_best=metric[1]

            #now childs become population and the entire process repeats
            self.population=self.childs
    # we need to make a function that computes the distance between the two points based on the x and the y coordinates
    
    def euc_dist(x_1,y_1,x_2,y_2):
        import math
        value=math.sqrt((x_1-x_2)**2+(y_1-y_2)**2)
        result=round(value)
        return result

    def nearest_neighbour_path(nodes):
        paths=[]
        #print("="*50)
        #print("running insertion neighbours method.......\n")
        while len(nodes)!=0:# do this when lines are not zero
            val=random.randint(0,len(nodes)-1)#pick a random node to be removed takes value inc upper bound hence -1
            node=nodes.pop(val) #take out that val in the nodes and save it as the node 
            metric=(node[0],node[1],node[2])# creates metric (city_name , x_c, y_c)

            if(len(paths)<=1):#at first paths is an empty list insert first two elements random

                dist=0 #for empty list dist is zero with prev element 
                paths.append(metric)#add this metric to the empty list

            else:#if the list is not empty ,meaning we have some elements before
                #we will compare distance of this element with all the prev elements

                distances=[] #an empty list with with distances 

                for elements in paths: 
                    dist=euc_dist(node[1],node[2],elements[1],elements[2])
                    distances.append((elements[0],dist))

                #print("already in paths: {}\n".format(paths))
                #print("the distances of pt {} are as follows:{}\n".format(node,distances))

                from operator import itemgetter # run a sort based on distances stored in tuple
                distances.sort(key=itemgetter(1))

                #print("the min distance value is : {}\n".format(distances[0])) #this is the min distance point

                ###find the index of the min distance in the node and insert it
                index_check=distances[0][0] #this is the city after which it should be inserted

                for numbers in paths: #look for that same element in the paths 
                    if(index_check==numbers[0]): #if index matches then
                        index=paths.index(numbers)#this is the index of the path node closest to the slected node
                        #print("found the index {}\n".format(index))
                        paths.insert(index+1,node) #put this element at index +1 pos and move everything right
                        break


        #print("paths are :{}\n".format(paths))

        #print(paths) #print the updated path
        first_ele=paths[0]

        #print("we also need to return back to first city , don't forget that, first element which is :{}".format(first_ele))
        if (paths[0]!=paths[-1]):#prevents over addition of same element on multiple run
            paths.append(first_ele)
        #print("="*50)
        return paths

    def chromozome_to_nodes(chromozome, nodes):
        """this function converts [1,2,3,4,5,1] to [(1,x cord of 1, y cord of 1),(2,x cord of 2, y cord of 2)........
        ...........,(5,x cord of 5, y cord of 5)]"""
        final=[]
        for city in chromozome:#for every element in chromozome
            for node in nodes: #for every node in nodes
                if (node[0]==city): #if the node index= city 
                    final.append(node)#add the full node value to final
        return final

    def overall_cost(paths):
        """given a list of lists it iterates through it and propogates through all nodes and calc distances"""
        total=0
        for i in range(len(paths)):
            try:
                dist=euc_dist(paths[i][1],paths[i][2],paths[i+1][1],paths[i+1][2])
                #print(dist)
            except:
                break
            total+=dist
        return total

    #parse out the values in a new folder in the directory called results and save cost and paths
    def parse_out(output_name, paths,cost): #takes file name and nodes
        first_line=str(cost)+"\n"
        file = open(output_name, "w") 
        file.write(first_line) 
        file.write("\n")
        for elements in paths :
            city=elements[0]
            city=str(city)
            file.write(city)
            file.write("\n")
        file.close() 
        pass

    def pick_nearest_start(nodes):
        #print("="*50)
        #print("running last node fast insertion method.......\n")
        paths=[]
        cost=0
        #print("\nthis is the begining >>>>")
        #print("\nthese are the nodes lot:{}".format(nodes))
        #print("\nthese are the paths lot:{}".format(paths))
        while nodes!=0: #as soon as nodes is empty >>>stop
            if(len(paths)==0 and len(nodes)>0):#its start 
                val=random.randint(0,len(nodes)-1)
                element_removed=nodes.pop(val)
                paths.append(element_removed)
                dist=0
                cost+=dist
            elif(len(paths)!=0 and len(nodes)==0):#termination stage
                #just add the first term back again
                paths.append(paths[0])
                dist=euc_dist(paths[-1][1],paths[-1][2],paths[-2][1],paths[-2][2])
                cost+=dist
                break

            else: #if length is not equal to 0 then there exists some city in the path alredy
                dist=[] # compare the distance of this element present in path already with all the elements in the nodes
                last_node=paths[-1]

                for elements in nodes:
                    d=euc_dist(last_node[1],last_node[2],elements[1],elements[2])
                    dist.append((elements[0],d)) #makes a d list with (city name , distance with the removed node )

                from operator import itemgetter # run a sort based on distances stored in tuple
                dist.sort(key=itemgetter(1))

                index_check=dist[0][0] #this is the city after which it should be inserted
                dist = dist[0][1]

                cost+=dist

                found= [item for item in nodes if (item[0] == index_check)]#search the index of closest node in nodes
                nodes.remove(found[0])#only select the city name and stack it with paths
                paths.append(found[0])

                del dist

        #print("="*50)
        return paths, dist

    #calculate the fitness
    def fitness_tsp(population,nodes):
        """takes entire population and a list of nodes or look up table
        returns fitness"""
        dist=[]
        for chromozomes in population:
            paths=chromozome_to_nodes(chromozomes,nodes)#converts chromozomes to nodes
            val=overall_cost(paths)#calculate the cost of the node path calculated
            fitness_val=1/val #we want the least distance to be most fit hence inverse function takes care of it 
            dist.append(fitness_val) #add fitness
        return dist


    def heuristic_population(nodes,sample_size):
        """this funtion returns me the values from insertion neightbour heuristic as population
        for the genetic algorithm"""
        import copy
        import numpy as np
        samples=[]
        for i in tqdm(range(sample_size)):
            tnodes=copy.deepcopy(nodes)
            paths_1=nearest_neighbour_path(tnodes)#makes random path using heuristic
            #print("final path values are:{}".format(paths_1)) 
            cost_1=overall_cost(paths_1)
            #print("\ntotal cost value is:{}".format(cost_1))
            a=[]
            for vals in paths_1: #chromozoin 
                a.append(vals[0])
            samples.append(a)
        #print("samples are :{}".format(samples)) 
        return samples

    def heuristic_population_fast(nodes,sample_size):
        """this funtion returns me the values from insertion neightbour heuristic as population
        for the genetic algorithm"""
        import copy
        import numpy as np
        samples=[]
        for i in tqdm(range(sample_size)):
            tnodes=copy.deepcopy(nodes)
            paths_1,cost_1=pick_nearest_start(tnodes)
            #print("final path values are:{}".format(paths_1)) 
            #print("\ntotal cost value is:{}".format(cost_1))
            a=[]
            for vals in paths_1:#for city names in a path
                a.append(vals[0])#add all the city names to a new list 
            samples.append(a)
        #print("samples are :{}".format(samples)) 
        return samples
    
    def random_samples(nodes,sample_size):
        import copy
        chromozome=[]
        for i in tqdm(range(sample_size)):
            tnodes=copy.deepcopy(nodes)
            temp=[]
            while len(tnodes)!=0:
                import random as random 
                val=random.randint(0,len(tnodes)-1)
                check=tnodes.pop(val)
                city_no=check[0]
                temp.append(city_no)
            temp.append(temp[0])#one samples generated
            chromozome.append(temp)#add first element back coz the tsp problem deals with returning back to the first city
        return chromozome#n such samples generated

    def probability_from_fitness(fitness_scores,population):
        """returns a tuple of probability based value and the corresponding path"""
        total_fitness=0
        prob=[]
        for element in fitness_scores:
            total_fitness+=element
        for element,chromozome in zip(fitness_scores,population):
            proba_val=element/total_fitness
            proba_val=(proba_val,chromozome)
            prob.append(proba_val)  
        return prob
    
    def prob_based_selection(prob_path,selection_vals):
        """this function randomly picks elements but prioritizes the higher prob routes
        returns me the prob based selected paths/chromozomes and how many we want is denoted by : selection_vals"""
        start=0
        roulette=[]#makes a roulette wheel with high values of the path
        for element in prob_path:
            start=start+element[0]
            metric=(start,element[1])
            roulette.append(metric)
        #print(roulette)

        #now pick a number between 0 and 1 and place it in roulette
        import random

        i=0; prob_based_paths=[]
        for i in range(selection_vals):
            num=random.uniform(0, 1)
            #print("prob_path:{}".format(num))
            #this part picks up the correct chromozome value corresponding to path selected
            start=0
            for element in roulette:
                if (num>=start and num<=element[0]):
                    #print( "value is :{}".format(element[1]))
                    prob_based_paths.append(element[1])
                    break
                else:
                    start=element[0]
                    continue
        return prob_based_paths

    def random_selection(chromozome_no,prob_values):
        """picks up any random values with no relation to probs"""
        #prob by sorted list
        import random
        sorted_by_prob = sorted(prob_values, key=lambda tup: tup[0],reverse=True)#sort by 0th pos i.e probabilities
        #print(sorted_by_prob)
        selected=[]
        for i in range(10):
            num=random.randint(0,len(sorted_by_prob))
            selected.append(sorted_by_prob[num][1])

        return selected
  

    def uniform1_cross_over(strand_1,strand_2):
        """applies uniform crossover over two strands of chromozome"""
        import random
        import math
        import copy

        ## remove the last element for simplicity
        strand_1=strand_1[:-1]
        strand_2=strand_2[:-1]
        #print(strand_1,strand_2)


        #we keep the 50% genes as the same 
        fixed_pos=[] #make a list of fixed pos
        while len(fixed_pos)<math.floor(len(strand_1)/2):
            val=random.randint(0,len(strand_1)-1) 
            if(val not in fixed_pos):
                fixed_pos.append(val)
        #print("fixed_pos are :{}".format(fixed_pos))

        c1={}; c2={}#this is what to be preserved
        #has dict values as - index:value to be put 

        for element in fixed_pos:
            c1[element]=strand_1[element]
            c2[element]=strand_2[element]

        #print("fixed c1 dict is :{} , c2 dict is :{}".format(c1,c2))

        #the alphabets that need to be preserved are there in the ditionaries 

        #now we need to get ourselves crossing over the other values 
        ind=0
        for element in strand_2:#for all values in strand 2
            if(element in c1.values()): #if element in c1 values
                continue
            else: #if element is not there in the c1 strand
                while (ind in c1.keys()):#checking the index in c1
                    ind+=1
                    continue
                c1[ind]=element #add to dictionary
                ind+=1

        #child-2 

        ind=0
        for element in strand_1:#for all values in strand 2
            if(element in c2.values()): #if element in c1 values
                continue
            else: #if element is not there in the c1 strand
                while (ind in c2.keys()):#checking the index in c1
                    ind+=1
                    continue
                c2[ind]=element #add to dictionary
                ind+=1

        #print("strand c1 is: {} , c2 is : {}".format(c1,c2))

        #after having the fixed pos move elements of strand 2 in list 1 and vice versa

        #reconstruction phase
        ch1=[];ch2=[]

        for key1,key2 in zip(sorted(c1.keys()),sorted(c2.keys())):
            val1=c1[key1]
            ch1.append(val1)
            val2=c2[key2]
            ch2.append(val2)

        #print(ch1,ch2)
        #now add the first element back to the strands 
        first=ch1[0]
        ch1.append(first)
        first=ch2[0]
        ch2.append(first)



        return ch1,ch2

    def exchange_mutation(strand_1,mutation):
        """takes strand to mutate and how many mutations to make
        returns the mutated strand"""
        import random
        cycle=0
        while cycle!=mutation: #cycle couter
            #we cant mutate the first city and last because that's the returning point
            first=random.randint(1,len(strand_1)-2)#why -2 because -1 for len value substract and another -1  not selecting last city
            second=random.randint(1,len(strand_1)-2)
            while(first==second):#to make sure the same two blocks are not selected
                second=random.randint(1,len(strand_1)-2) 
            #now we apply mutation by swapping numbers
            strand_1[first],strand_1[second]=strand_1[second],strand_1[first] #swapping operation
            cycle+=1

        return strand_1
    
    def inversion_mutation(strand_1,mutation):
        """takes strand to mutate and how many mutations to make
        returns the mutated strand"""
        import random
        cycle=0
        strand_1=strand_1[:-1]
        while cycle!=mutation: #cycle couter
            #we cant mutate the first city and last because that's the returning point
            first=random.randint(0,len(strand_1)-1)#not to select the last city
            second=random.randint(0,len(strand_1)-1)
            while(first==second):#to make sure the same two blocks are not selected
                second=random.randint(0,len(strand_1)-1) 
            if (first>second):
                first,second=second,first
            print(first,second)
            #now we apply mutation by swapping numbers
            select=strand_1[first:second+1] #inversion operation
            print(select)
            new=[]#make new strand
            for i in reversed(select):
                new.append(i)
            print(new)
            strand_1[first:second+1] =new#replace selceted with new strand
            cycle+=1
            
        first=strand_1[0]
        strand_1.append(first) 
        return strand_1
    
    def parse_out(self): #takes file name and nodes
        """write in a folder called test run"""
        import os
        path = os.getcwd()
        #this is the name of the folder where data is <<<<#turning this off may help
        os.chdir(path) #navigate to path
        current=min(self.generation_best, key = lambda t: t[1]) #find the min element of based on distance
        path=current[0]
        cost=current[1]
        k="_"#a gap that you want to add
        output_name=str(self.file)+k+str(self.generation)[0]+k+str(self.selection)[0]+k+str(self.cross_over)[0]+k+str(self.mutation)[0]+k+str(self._iter)+".txt"
        #output_name=str(self.file)+k+"config-1"  #<<<<if you want config wise naming
        first_line="cities: "+str(self.nodes_count)+"cost: "+str(cost)
        file = open(output_name, "w") 
        file.write(first_line) 
        file.write("\n")
        for elements in path :
            city=str(elements)
            file.write(city)
            file.write("\n")
        file.close() 
        print("file write successful in :{}".format(path))
        os.chdir('..')#move back one lev now

#file_name ="r_s_u_r_500"+"_"+str(overall_best[1])+".txt"
#parse_out(file_name,overall_best[0],nodes_count,overall_best[1])


# In[ ]:


random.seed(183262)
file="inst-4.tsp" #file you want to run your code on
#you might need to put your file in the same directory level if this re run does not work


population_generation="random" #how you want to generate initial population
pop_size=100 #size of the initial population you want to keep
selection="sus"#selection type that y
selection_size=10 #basically how many you want to put into mating pool
cross_over="uniform"#which cross over do you want to use
mutation="reciprocal"#which type of mutation do you want to use
mutation_rate=.1 #how many bits you want mutate depends on this rate to occur (eq to 0.1 mutation rate)
_iter=500 #uptil how many generations do you want to run the code for

#for i in range(5):<<<turn this on or off if you want to run multiple run of the same algorithm as Diarmuid pointed in 
#Discussion forums since seed is set the results can be different for 5 runs still being reproducable
t=tsp(file,population_generation,pop_size,selection,selection_size,cross_over,mutation,mutation_rate,_iter)
t.current_best


# In[ ]:


t.current_best


# In[ ]:


t.parse_out()


# In[ ]:


path=os.getcwd()
print(path)


# 

# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




