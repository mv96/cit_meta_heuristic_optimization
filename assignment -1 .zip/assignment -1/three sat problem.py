#!/usr/bin/env python
# coding: utf-8

# In[1]:


#this is the 3 sat problem 
import random

random.seed( 183262 ) #this is my roll number seed 


# v- (or +)
# ^- (and .)
# F = (x∨p)∧(-x∨y∨z∨-p)∧(-y∨q∨-z) 
# 
# 2 literals>>>> x V p =(x V p V a) ^ (x V p V - a ) #add a variable and negate it 
# 
# 3+ literals>>>> -x + y +z+ -p = (-x+y+b).(-b+z+-p) #break into two sub literals
# 
# 3 exactly keep the same: (-y∨q∨-z)=(-y∨q∨-z)
# 
# reduced expression>>>>
# 
# 1 = (x or p or a) and (x or p or not( a) )
# 
# 2=  ( not(x) or y or b) and ( not(b) or z or not(p))
# 
# 3=  (-y or q or not(z))
#     
# for F to be true we have 
# reduce it to  F= 1 or 2 or 3
# If x= true 1st exp= True , y = true 2nd exp =true ,-z =true /z=false
# 
# 

# In[2]:


#3 sat check
def sat_check(x,y,z,p,q):
    F = (x or p) and ((not x) or y or z or (not p)) and ((not y) or q or (not z))
    return F
    


# In[3]:


def sat_3_check(x,y,z,p,q):
    import random
    a=random.randint(0,1)
    b=random.randint(0,1)
    if(a==1):
        a=True
    else:
        a=False
    if(b==1):
        b=True
    else:
        b=False
    one= (x or p or a) and (x or p or not( a) )
    two= (not(x) or y or b) and ( not(b) or z or not(p))
    three= (not(y) or q or not(z))
    return one and two and three
    


# In[4]:


x=True
y=True
z=False
p=False
q=True
result=True
for i in range(1000):
    exp_1=sat_check(x,y,z,p,q)
    exp_2=sat_3_check(x,y,z,p,q)
    result=result and exp_1 and exp_2
print("the solution satisfies sat and 3 sat problem: {}".format(result))


# x=true , y=true, z=false, p=true, q=true the solution that satisfies sat as well as 3 sat

# problem for assignment
# 
# 1> Sat check
# F = (z1 ∨ -z2) ∧ (-z1 ∨ z2 ∨z3 ∨z4 ∨ z5)
# 

# In[5]:


def sat_check(x,y,z,p,q):
    F = (x or (not y)) and ((not x) or y or z or p or q)
    return F


# 
# 2> 3-sat check
# 
# F'= (z1 ∨ -z2 ∨ a) ∧ (z1 ∨ -z2 ∨ -a) ∧ (-z1 ∨ z2 ∨ b) ∧ (-b ∨ z3 ∨ c) ∧ (-c ∨ z4 ∨ z5)

# In[6]:


def sat_3_check(x,y,z,p,q):
    import random
    a=random.randint(0,1)
    b=random.randint(0,1)
    c=random.randint(0,1)
    if(a==1):
        a=True
    else:
        a=False
    if(b==1):
        b=True
    else:
        b=False
    if(c==1):
        c=True
    else:
        c=False
    one= x or (not y) or a
    two= x or (not y) or  (not a)
    three= not x or y or b
    four= not b or z or c
    five= not c or p or q
    return one and two and three and four and five


# In[7]:


x=True
y=True
z=True
p=True
q=False
result=True
for i in range(1000):
    exp_1=sat_check(x,y,z,p,q)
    exp_2=sat_3_check(x,y,z,p,q)
    result=result and exp_1 and exp_2
print("the solution satisfies sat and 3 sat problem: {}".format(result))


# solution is z1, z2 ,z3 ,z4 > True everything else does not matter you can keep whatever you want

# In[ ]:





# In[ ]:




